# Taskboard [![Build Status](https://travis-ci.org/tarlepp/Taskboard.png?branch=master)](https://travis-ci.org/tarlepp/Taskboard)
### a Sails application to mimic "scrum-ban" taskboard.

![ScreenShot](http://tarlepp.github.io/Taskboard/images/screenshots/board_01.png)

More information @ http://tarlepp.github.io/Taskboard/

### Demo

Maybe sails are lifted on http://wunder.sytes.net:1337/ or maybe not...

Try it with following credentials:
```
username: demo
password: demodemodemo
```


