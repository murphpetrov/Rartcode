module.exports.i18n = {
    // Which locales are supported?
    locales: ['en', 'fi'],

    // Where are your locale translations located?
    localesDirectory: '/config/locales'
};
